<span class="screen-darken"></span>
<!-- loader Start -->
<!-- loader Start -->
<div class="loader simple-loader">
    <div class="loader-body">
        <img src="./assets/images/loader.gif" alt="loader" class="img-fluid" width="300" />
    </div>
</div>
