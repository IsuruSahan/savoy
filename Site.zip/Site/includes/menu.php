
 <header class="header-center-home header-default header-sticky">
         <nav class="nav navbar navbar-expand-xl navbar-light iq-navbar header-hover-menu py-xl-0">
            <div class="container-fluid navbar-inner">
               <div class="d-flex align-items-center justify-content-between w-100 landing-header">
                  <div class="d-flex gap-3 gap-xl-0 align-items-center">
                     <div>
                        <button type="button" data-bs-toggle="offcanvas" data-bs-target="#navbar_main"
                           aria-controls="navbar_main"
                           class="d-xl-none btn btn-primary rounded-pill p-1 pt-0 toggle-rounded-btn">
                           <svg width="20px" class="icon-20" viewBox="0 0 24 24">
                              <path fill="currentColor"
                                 d="M4,11V13H16L10.5,18.5L11.92,19.92L19.84,12L11.92,4.08L10.5,5.5L16,11H4Z"></path>
                           </svg>
                        </button>
                     </div>
                     <!--Logo -->
                     <div class="logo-default">
                         <a class="navbar-brand text-primary" href="./index.php"> 
                             <img class="img-fluid logo" src="./assets/images/logo.webp" loading="lazy" alt="EAP" />
                         </a>
                     </div>
                     
                     
                     
      
                  </div>
                  <nav id="navbar_main" class="offcanvas mobile-offcanvas nav navbar navbar-expand-xl hover-nav horizontal-nav mega-menu-content py-xl-0">
                    <div class="container-fluid p-lg-0">
                      <div class="offcanvas-header px-0">
                        <div class="navbar-brand ms-3">
                          <!--Logo -->
                          <div class="logo-default">
                              <a class="navbar-brand text-primary" href="./index.php"> 
                                  <img class="img-fluid logo" src="./assets/images/logo.webp" loading="lazy" alt="EAP" />
                              </a>
                          </div>
                          
                        
                        </div>
                        <button type="button" class="btn-close float-end px-3" data-bs-dismiss="offcanvas" aria-label="Close"></button>
                      </div>
                      <ul class="navbar-nav iq-nav-menu  list-unstyled" id="header-menu">
                        <li class="nav-item">
                        <a class="nav-link " href="index.php">HOME
                            <span class="menu-icon">
                             
                              <span class="toggle-menu">
                                <i class="fa fa-plus  arrow-active text-white" aria-hidden="true"></i>
                                <i class="fa fa-minus  arrow-hover text-white" aria-hidden="true"></i>
                              </span>
                            </span>
                          </a>
                         </li>
                        <li class="nav-item">
                        <a class="nav-link " href="all-movie.php"> MOVIES
                            <span class="menu-icon">
                              
                              <span class="toggle-menu">
                                <i class="fa fa-plus  arrow-active text-white" aria-hidden="true"></i>
                                <i class="fa fa-minus  arrow-hover text-white" aria-hidden="true"></i>
                              </span>
                            </span>
                          </a>
                          
                        </li>
                        <li class="nav-item">
                        <a class="nav-link " href="about-us.php">ABOUT US
                            <span class="menu-icon">
                            
                              <span class="toggle-menu">
                                <i class="fa fa-plus  arrow-active text-white" aria-hidden="true"></i>
                                <i class="fa fa-minus  arrow-hover text-white" aria-hidden="true"></i>
                              </span>
                            </span>
                          </a>
                         
                        </li>
                        <li class="nav-item">
                        <a class="nav-link " href="buy-tickets.php">BUY TICKETS
                            <span class="menu-icon">
                              
                              <span class="toggle-menu">
                                <i class="fa fa-plus  arrow-active text-white" aria-hidden="true"></i>
                                <i class="fa fa-minus  arrow-hover text-white" aria-hidden="true"></i>
                              </span>
                            </span>
                          </a>
                          
                        </li>
                        <li class="nav-item">
                           <a class="nav-link " href="contact-us.php">CONTACT US
                            <span class="menu-icon">
                             
                              <span class="toggle-menu">
                                <i class="fa fa-plus  arrow-active text-white" aria-hidden="true"></i>
                                <i class="fa fa-minus  arrow-hover text-white" aria-hidden="true"></i>
                              </span>
                            </span>
                          </a>
                         
                        </li>
                      </ul>
                    </div>
                    <!-- container-fluid.// -->
                  </nav>            
                
               </div>
            </div>
         </nav>
      </header>      <!--Nav End-->
