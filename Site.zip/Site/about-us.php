<!doctype html>
<html lang="en" data-bs-theme="dark">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <title>EAP Films and Theatres Private Limited | About Us</title>
  <!-- Google Font Api KEY-->
  <meta name="google_font_api" content="AIzaSyBG58yNdAjc20_8jAvLNSVi9E4Xhwjau_k">
  
  <!-- Favicon -->
  <link rel="shortcut icon" href="./assets/images/favicon.ico" />
  
  <!-- Library / Plugin Css Build -->
  <link rel="stylesheet" href="./assets/css/core/libs.min.css" />
  
  <!-- font-awesome css -->
  <link rel="stylesheet" href="./assets/vendor/font-awesome/css/all.min.css" />
  
  <!-- Iconly css -->
  <link rel="stylesheet" href="./assets/vendor/iconly/css/style.css" />
  
  <!-- Animate css -->
  <link rel="stylesheet" href="./assets/vendor/animate.min.css" />
  
  <!-- Streamit Design System Css -->
  <link rel="stylesheet" href="./assets/css/streamit.min.css?v=1.0.0" />
  
  <!-- Custom Css -->
  <link rel="stylesheet" href="./assets/css/custom.min.css?v=1.0.0" />
  
  <!-- Rtl Css -->
  <link rel="stylesheet" href="./assets/css/rtl.min.css?v=1.0.0" />
  
  <!-- Google Font -->
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Roboto:ital,wght@0,300;0,400;0,500;0,700;0,900;1,300&display=swap" rel="stylesheet">
  
</head>

<style>

.image5{
    width:70%;
    margin-top:-7rem;
}

.container1{   
    margin-bottom:-8rem;  
}

@media only screen and (max-width: 1080px) {
    .image5{
     margin-top:0rem;
}

.container1{
   
   margin-bottom:1rem;
}
}

</style>

<body class="  ">
<?php include 'includes/loader.php';?>

  <main class="main-content">

  <?php include 'includes/menu.php';?>

      <!--bread-crumb-->
      <div class="iq-breadcrumb" style="background-image: url(./assets/images/pages/01.webp);">
         <div class="container-fluid">
            <div class="row align-items-center">
                  <div class="col-sm-12">
                      <nav aria-label="breadcrumb" class="text-center">
                          <h2 class="title">About Us</h2>
                          <ol class="breadcrumb justify-content-center">
                              <!-- <li class="breadcrumb-item"><a href="./index.html">Home</a></li> 
                              <li class="breadcrumb-item active">About Us</li> -->
                          </ol>
                      </nav>
                  </div>
              </div> 
         </div>
      </div>      
      
      <!--bread-crumb-->

<div class="section-padding">
    <div class="container">
        
    <div class="container px-4">
        <div class="row gx-5">
            <div class="col-md-6">
                <img src="./assets/images/footer-logo/eap.png" alt="geners-img" class="image5">
            </div>
            <div class="col-md-6">
            <div>
                <h3 class="text-white">EAP Films & Theaters</h3>
                <p class="text-white">EAP Films, the unrivaled market leader in the Sri Lankan Film Industry,
                     dedicated to providing an exceptional entertainment platform for cinephiles. 
                     We proudly manage and operate over 45 contemporary cinemas across the island, 
                     catering to a vast annual patrons' base exceeding 5.5 million, our focus extends to 
                     the middle and high-end market within the city limits. Our vision is to be the trusted leader 
                     in cinema entertainment, serving as a beacon of innovation and change with sustainable value for
                     all our stakeholders.</p>

              </div>
            </div>
        </div>
    </div>
    <!-- --------------- -->
    <div class="container1 px-4">
        <div class="row gx-5">
            <div class="col-md-6">
                <img src="./assets/images/footer-logo/sav.png" alt="geners-img" class="image5">
            </div>
            <div class="col-md-6">
            <div>
                <h3 class="text-white">SAVOY CINEMA</h3>
                <p class="text-white">Savoy Cinema, a distinguished cinematic oasis, renowned as Savoy Cinema Circuit that’s located island wide. 
                    Beyond its illustrious ownership, Savoy Cinema captivates audiences with its cutting-edge facilities, combining the latest in 
                    cinematic technology. Immerse yourself in the captivating world of Savoy 3D Cinema, where state-of-the-art visuals transport 
                    you to new dimensions of storytelling whilst offering a unique cinematic experience, presenting a diverse array of films in 
                    a cozy and inviting atmosphere. Savoy Cinema invites you to embark on a cinematic journey where passion meets innovation, 
                    creating an unforgettable experience for every movie enthusiast.</p>
            </div>
            </div>
        </div>
    </div>   
    </div>
</div>


  </main>

  <?php include 'includes/footer.php';?>

  <?php include 'includes/gototop.php';?>
  <!-- Wrapper End-->
  <!-- Library Bundle Script -->
  <script src="./assets/js/core/libs.min.js"></script>
  <!-- Plugin Scripts -->

  <!-- Lodash Utility -->
  <script src="./assets/vendor/lodash/lodash.min.js"></script>
  <!-- External Library Bundle Script -->
  <script src="./assets/js/core/external.min.js"></script>
  <!-- countdown Script -->
  <script src="./assets/js/plugins/countdown.js"></script>
  <!-- utility Script -->
  <script src="./assets/js/utility.js"></script>
  <!-- Setting Script -->
  <script src="./assets/js/setting.js"></script>
  <script src="./assets/js/setting-init.js" defer></script>
  <!-- Streamit Script -->
  <script src="./assets/js/streamit.js" defer></script>
  <script src="./assets/js/swiper.js" defer></script>
</body>

</html>