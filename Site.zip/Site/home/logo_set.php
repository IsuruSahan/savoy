<!-- <div class="movie-geners-block">
  <div class="container-fluid">
    <div class="overflow-hidden">
      <div class="card-style-slider">
        <div class="position-relative swiper swiper-card swiper-card-anime" data-slide="6" data-laptop="6" data-tab="3" data-mobile="2" data-mobile-sm="2" data-autoplay="false" data-loop="true" data-navigation="true" data-pagination="true">
          <ul class="p-0 swiper-wrapper m-0  list-inline geners-card">
            <li class="swiper-slide">
            <div class="iq-card-geners card-hover-style-two">
                <div class="block-images position-relative w-100">
                    <div class="img-box rounded position-relative">
                        <img src="./assets/images/footer-logo/1.webp" alt="geners-img" class="img-fluid object-cover w-100 rounded">
                        
                    </div>
                </div>
            </div>
          </li>
          <li class="swiper-slide">
            <div class="iq-card-geners card-hover-style-two">
                <div class="block-images position-relative w-100">
                    <div class="img-box rounded position-relative">
                        <img src="./assets/images/footer-logo/2.webp" alt="geners-img" class="img-fluid object-cover w-100 rounded">
                       
                    </div>
                </div>
            </div>
          </li>
          <li class="swiper-slide">
            <div class="iq-card-geners card-hover-style-two">
                <div class="block-images position-relative w-100">
                    <div class="img-box rounded position-relative">
                        <img src="./assets/images/footer-logo/3.webp" alt="geners-img" class="img-fluid object-cover w-100 rounded">
                        
                    </div>
                </div>
            </div>
          </li>
          <li class="swiper-slide">
            <div class="iq-card-geners card-hover-style-two">
                <div class="block-images position-relative w-100">
                    <div class="img-box rounded position-relative">
                        <img src="./assets/images/footer-logo/4.webp" alt="geners-img" class="img-fluid object-cover w-100 rounded">
                        
                    </div>
                </div>
            </div>
          </li>
          <li class="swiper-slide">
            <div class="iq-card-geners card-hover-style-two">
                <div class="block-images position-relative w-100">
                    <div class="img-box rounded position-relative">
                        <img src="./assets/images/footer-logo/5.webp" alt="geners-img" class="img-fluid object-cover w-100 rounded">
                        
                    </div>
                </div>
            </div>
          </li>
         
          <li class="swiper-slide">
            <div class="iq-card-geners card-hover-style-two">
                <div class="block-images position-relative w-100">
                    <div class="img-box rounded position-relative">
                        <img src="./assets/images/footer-logo/7.webp" alt="geners-img" class="img-fluid object-cover w-100 rounded">
                       
                    </div>
                </div>
            </div>
          </li>

          <li class="swiper-slide">
            <div class="iq-card-geners card-hover-style-two">
                <div class="block-images position-relative w-100">
                    <div class="img-box rounded position-relative">
                        <img src="./assets/images/footer-logo/8.webp" alt="geners-img" class="img-fluid object-cover w-100 rounded">
                       
                    </div>
                </div>
            </div>
          </li>

          <li class="swiper-slide">
            <div class="iq-card-geners card-hover-style-two">
                <div class="block-images position-relative w-100">
                    <div class="img-box rounded position-relative">
                        <img src="./assets/images/footer-logo/9.webp" alt="geners-img" class="img-fluid object-cover w-100 rounded">
                       
                    </div>
                </div>
            </div>
          </li>


          <li class="swiper-slide">
            <div class="iq-card-geners card-hover-style-two">
                <div class="block-images position-relative w-100">
                    <div class="img-box rounded position-relative">
                        <img src="./assets/images/footer-logo/10.webp" alt="geners-img" class="img-fluid object-cover w-100 rounded">
                       
                    </div>
                </div>
            </div>
          </li>

          <li class="swiper-slide">
            <div class="iq-card-geners card-hover-style-two">
                <div class="block-images position-relative w-100">
                    <div class="img-box rounded position-relative">
                        <img src="./assets/images/footer-logo/11.webp" alt="geners-img" class="img-fluid object-cover w-100 rounded">
                       
                    </div>
                </div>
            </div>
          </li>

          <li class="swiper-slide">
            <div class="iq-card-geners card-hover-style-two">
                <div class="block-images position-relative w-100">
                    <div class="img-box rounded position-relative">
                        <img src="./assets/images/footer-logo/12.webp" alt="geners-img" class="img-fluid object-cover w-100 rounded">
                       
                    </div>
                </div>
            </div>
          </li>

          <li class="swiper-slide">
            <div class="iq-card-geners card-hover-style-two">
                <div class="block-images position-relative w-100">
                    <div class="img-box rounded position-relative">
                        <img src="./assets/images/footer-logo/13.webp" alt="geners-img" class="img-fluid object-cover w-100 rounded">
                       
                    </div>
                </div>
            </div>
          </li>

          <li class="swiper-slide">
            <div class="iq-card-geners card-hover-style-two">
                <div class="block-images position-relative w-100">
                    <div class="img-box rounded position-relative">
                        <img src="./assets/images/footer-logo/14.webp" alt="geners-img" class="img-fluid object-cover w-100 rounded">
                       
                    </div>
                </div>
            </div>
          </li>

          <li class="swiper-slide">
            <div class="iq-card-geners card-hover-style-two">
                <div class="block-images position-relative w-100">
                    <div class="img-box rounded position-relative">
                        <img src="./assets/images/footer-logo/15.webp" alt="geners-img" class="img-fluid object-cover w-100 rounded">
                       
                    </div>
                </div>
            </div>
          </li>

          <li class="swiper-slide">
            <div class="iq-card-geners card-hover-style-two">
                <div class="block-images position-relative w-100">
                    <div class="img-box rounded position-relative">
                        <img src="./assets/images/footer-logo/16.webp" alt="geners-img" class="img-fluid object-cover w-100 rounded">
                       
                    </div>
                </div>
            </div>
          </li>

          <li class="swiper-slide">
            <div class="iq-card-geners card-hover-style-two">
                <div class="block-images position-relative w-100">
                    <div class="img-box rounded position-relative">
                        <img src="./assets/images/footer-logo/17.webp" alt="geners-img" class="img-fluid object-cover w-100 rounded">
                       
                    </div>
                </div>
            </div>
          </li>

          <li class="swiper-slide">
            <div class="iq-card-geners card-hover-style-two">
                <div class="block-images position-relative w-100">
                    <div class="img-box rounded position-relative">
                        <img src="./assets/images/footer-logo/18.webp" alt="geners-img" class="img-fluid object-cover w-100 rounded">
                       
                    </div>
                </div>
            </div>
          </li>

          <li class="swiper-slide">
            <div class="iq-card-geners card-hover-style-two">
                <div class="block-images position-relative w-100">
                    <div class="img-box rounded position-relative">
                        <img src="./assets/images/footer-logo/19.webp" alt="geners-img" class="img-fluid object-cover w-100 rounded">
                       
                    </div>
                </div>
            </div>
          </li>

          <li class="swiper-slide">
            <div class="iq-card-geners card-hover-style-two">
                <div class="block-images position-relative w-100">
                    <div class="img-box rounded position-relative">
                        <img src="./assets/images/footer-logo/20.webp" alt="geners-img" class="img-fluid object-cover w-100 rounded">
                       
                    </div>
                </div>
            </div>
          </li>

          <li class="swiper-slide">
            <div class="iq-card-geners card-hover-style-two">
                <div class="block-images position-relative w-100">
                    <div class="img-box rounded position-relative">
                        <img src="./assets/images/footer-logo/21.webp" alt="geners-img" class="img-fluid object-cover w-100 rounded">
                       
                    </div>
                </div>
            </div>
          </li>

          <li class="swiper-slide">
            <div class="iq-card-geners card-hover-style-two">
                <div class="block-images position-relative w-100">
                    <div class="img-box rounded position-relative">
                        <img src="./assets/images/footer-logo/22.webp" alt="geners-img" class="img-fluid object-cover w-100 rounded">
                       
                    </div>
                </div>
            </div>
          </li>

          <li class="swiper-slide">
            <div class="iq-card-geners card-hover-style-two">
                <div class="block-images position-relative w-100">
                    <div class="img-box rounded position-relative">
                        <img src="./assets/images/footer-logo/23.webp" alt="geners-img" class="img-fluid object-cover w-100 rounded">
                       
                    </div>
                </div>
            </div>
          </li>

          <li class="swiper-slide">
            <div class="iq-card-geners card-hover-style-two">
                <div class="block-images position-relative w-100">
                    <div class="img-box rounded position-relative">
                        <img src="./assets/images/footer-logo/24.webp" alt="geners-img" class="img-fluid object-cover w-100 rounded">
                       
                    </div>
                </div>
            </div>
          </li>

          <li class="swiper-slide">
            <div class="iq-card-geners card-hover-style-two">
                <div class="block-images position-relative w-100">
                    <div class="img-box rounded position-relative">
                        <img src="./assets/images/footer-logo/31.webp" alt="geners-img" class="img-fluid object-cover w-100 rounded">
                       
                    </div>
                </div>
            </div>
          </li>


          <li class="swiper-slide">
            <div class="iq-card-geners card-hover-style-two">
                <div class="block-images position-relative w-100">
                    <div class="img-box rounded position-relative">
                        <img src="./assets/images/footer-logo/91.webp" alt="geners-img" class="img-fluid object-cover w-100 rounded">
                       
                    </div>
                </div>
            </div>
          </li>

          



          </ul>
          <div class="swiper-button swiper-button-next"></div>
          <div class="swiper-button swiper-button-prev"></div>
        </div>
      </div>
    </div>
  </div>
</div> -->


<div class="movie-geners-block">
  <div class="container-fluid">
    <div class="overflow-hidden">
      <div class="card-style-slider">
        <div class="position-relative swiper swiper-card swiper-card-anime" 
             data-slide="6" 
             data-laptop="6" 
             data-tab="3" 
             data-mobile="2" 
             data-mobile-sm="2" 
             data-autoplay="true" 
             data-delay="5000" 
             data-loop="true" 
             data-navigation="true" 
             data-pagination="true">
          <ul class="p-0 swiper-wrapper m-0 list-inline geners-card">
            <li class="swiper-slide">
              <div class="iq-card-geners card-hover-style-two">
                <div class="block-images position-relative w-100">
                  <div class="img-box rounded position-relative">
                    <img src="./assets/images/footer-logo/1.webp" alt="geners-img" class="img-fluid object-cover w-100 rounded">
                  </div>
                </div>
              </div>
            </li>
            

            <li class="swiper-slide">
            <div class="iq-card-geners card-hover-style-two">
                <div class="block-images position-relative w-100">
                    <div class="img-box rounded position-relative">
                        <img src="./assets/images/footer-logo/2.webp" alt="geners-img" class="img-fluid object-cover w-100 rounded">
                        
                    </div>
                </div>
            </div>
          </li>
          <li class="swiper-slide">
            <div class="iq-card-geners card-hover-style-two">
                <div class="block-images position-relative w-100">
                    <div class="img-box rounded position-relative">
                        <img src="./assets/images/footer-logo/3.webp" alt="geners-img" class="img-fluid object-cover w-100 rounded">
                       
                    </div>
                </div>
            </div>
          </li>
          <li class="swiper-slide">
            <div class="iq-card-geners card-hover-style-two">
                <div class="block-images position-relative w-100">
                    <div class="img-box rounded position-relative">
                        <img src="./assets/images/footer-logo/4.webp" alt="geners-img" class="img-fluid object-cover w-100 rounded">
                        
                    </div>
                </div>
            </div>
          </li>
          <li class="swiper-slide">
            <div class="iq-card-geners card-hover-style-two">
                <div class="block-images position-relative w-100">
                    <div class="img-box rounded position-relative">
                        <img src="./assets/images/footer-logo/5.webp" alt="geners-img" class="img-fluid object-cover w-100 rounded">
                        
                    </div>
                </div>
            </div>
          </li>
          <li class="swiper-slide">
            <div class="iq-card-geners card-hover-style-two">
                <div class="block-images position-relative w-100">
                    <div class="img-box rounded position-relative">
                        <img src="./assets/images/footer-logo/6.webp" alt="geners-img" class="img-fluid object-cover w-100 rounded">
                        
                    </div>
                </div>
            </div>
          </li>
         
          <!-- <li class="swiper-slide">
            <div class="iq-card-geners card-hover-style-two">
                <div class="block-images position-relative w-100">
                    <div class="img-box rounded position-relative">
                        <img src="./assets/images/footer-logo/7.webp" alt="geners-img" class="img-fluid object-cover w-100 rounded">
                       
                    </div>
                </div>
            </div>
          </li> -->

          <li class="swiper-slide">
            <div class="iq-card-geners card-hover-style-two">
                <div class="block-images position-relative w-100">
                    <div class="img-box rounded position-relative">
                        <img src="./assets/images/footer-logo/8.webp" alt="geners-img" class="img-fluid object-cover w-100 rounded">
                       
                    </div>
                </div>
            </div>
          </li>

          <li class="swiper-slide">
            <div class="iq-card-geners card-hover-style-two">
                <div class="block-images position-relative w-100">
                    <div class="img-box rounded position-relative">
                        <img src="./assets/images/footer-logo/9.webp" alt="geners-img" class="img-fluid object-cover w-100 rounded">
                       
                    </div>
                </div>
            </div>
          </li>


          <li class="swiper-slide">
            <div class="iq-card-geners card-hover-style-two">
                <div class="block-images position-relative w-100">
                    <div class="img-box rounded position-relative">
                        <img src="./assets/images/footer-logo/10.webp" alt="geners-img" class="img-fluid object-cover w-100 rounded">
                       
                    </div>
                </div>
            </div>
          </li>

          <li class="swiper-slide">
            <div class="iq-card-geners card-hover-style-two">
                <div class="block-images position-relative w-100">
                    <div class="img-box rounded position-relative">
                        <img src="./assets/images/footer-logo/11.webp" alt="geners-img" class="img-fluid object-cover w-100 rounded">
                       
                    </div>
                </div>
            </div>
          </li>

          <li class="swiper-slide">
            <div class="iq-card-geners card-hover-style-two">
                <div class="block-images position-relative w-100">
                    <div class="img-box rounded position-relative">
                        <img src="./assets/images/footer-logo/12.webp" alt="geners-img" class="img-fluid object-cover w-100 rounded">
                       
                    </div>
                </div>
            </div>
          </li>

          <li class="swiper-slide">
            <div class="iq-card-geners card-hover-style-two">
                <div class="block-images position-relative w-100">
                    <div class="img-box rounded position-relative">
                        <img src="./assets/images/footer-logo/13.webp" alt="geners-img" class="img-fluid object-cover w-100 rounded">
                       
                    </div>
                </div>
            </div>
          </li>

          <li class="swiper-slide">
            <div class="iq-card-geners card-hover-style-two">
                <div class="block-images position-relative w-100">
                    <div class="img-box rounded position-relative">
                        <img src="./assets/images/footer-logo/14.webp" alt="geners-img" class="img-fluid object-cover w-100 rounded">
                       
                    </div>
                </div>
            </div>
          </li>

          <li class="swiper-slide">
            <div class="iq-card-geners card-hover-style-two">
                <div class="block-images position-relative w-100">
                    <div class="img-box rounded position-relative">
                        <img src="./assets/images/footer-logo/15.webp" alt="geners-img" class="img-fluid object-cover w-100 rounded">
                       
                    </div>
                </div>
            </div>
          </li>

          <li class="swiper-slide">
            <div class="iq-card-geners card-hover-style-two">
                <div class="block-images position-relative w-100">
                    <div class="img-box rounded position-relative">
                        <img src="./assets/images/footer-logo/16.webp" alt="geners-img" class="img-fluid object-cover w-100 rounded">
                       
                    </div>
                </div>
            </div>
          </li>

          <li class="swiper-slide">
            <div class="iq-card-geners card-hover-style-two">
                <div class="block-images position-relative w-100">
                    <div class="img-box rounded position-relative">
                        <img src="./assets/images/footer-logo/17.webp" alt="geners-img" class="img-fluid object-cover w-100 rounded">
                       
                    </div>
                </div>
            </div>
          </li>

          <li class="swiper-slide">
            <div class="iq-card-geners card-hover-style-two">
                <div class="block-images position-relative w-100">
                    <div class="img-box rounded position-relative">
                        <img src="./assets/images/footer-logo/18.webp" alt="geners-img" class="img-fluid object-cover w-100 rounded">
                       
                    </div>
                </div>
            </div>
          </li>

          <li class="swiper-slide">
            <div class="iq-card-geners card-hover-style-two">
                <div class="block-images position-relative w-100">
                    <div class="img-box rounded position-relative">
                        <img src="./assets/images/footer-logo/19.webp" alt="geners-img" class="img-fluid object-cover w-100 rounded">
                       
                    </div>
                </div>
            </div>
          </li>

          <li class="swiper-slide">
            <div class="iq-card-geners card-hover-style-two">
                <div class="block-images position-relative w-100">
                    <div class="img-box rounded position-relative">
                        <img src="./assets/images/footer-logo/20.webp" alt="geners-img" class="img-fluid object-cover w-100 rounded">
                       
                    </div>
                </div>
            </div>
          </li>

          <li class="swiper-slide">
            <div class="iq-card-geners card-hover-style-two">
                <div class="block-images position-relative w-100">
                    <div class="img-box rounded position-relative">
                        <img src="./assets/images/footer-logo/21.webp" alt="geners-img" class="img-fluid object-cover w-100 rounded">
                       
                    </div>
                </div>
            </div>
          </li>

          <li class="swiper-slide">
            <div class="iq-card-geners card-hover-style-two">
                <div class="block-images position-relative w-100">
                    <div class="img-box rounded position-relative">
                        <img src="./assets/images/footer-logo/22.webp" alt="geners-img" class="img-fluid object-cover w-100 rounded">
                       
                    </div>
                </div>
            </div>
          </li>

          <li class="swiper-slide">
            <div class="iq-card-geners card-hover-style-two">
                <div class="block-images position-relative w-100">
                    <div class="img-box rounded position-relative">
                        <img src="./assets/images/footer-logo/23.webp" alt="geners-img" class="img-fluid object-cover w-100 rounded">
                       
                    </div>
                </div>
            </div>
          </li>

          <li class="swiper-slide">
            <div class="iq-card-geners card-hover-style-two">
                <div class="block-images position-relative w-100">
                    <div class="img-box rounded position-relative">
                        <img src="./assets/images/footer-logo/24.webp" alt="geners-img" class="img-fluid object-cover w-100 rounded">
                       
                    </div>
                </div>
            </div>
          </li>

          <li class="swiper-slide">
            <div class="iq-card-geners card-hover-style-two">
                <div class="block-images position-relative w-100">
                    <div class="img-box rounded position-relative">
                        <img src="./assets/images/footer-logo/31.webp" alt="geners-img" class="img-fluid object-cover w-100 rounded">
                       
                    </div>
                </div>
            </div>
          </li>


          <li class="swiper-slide">
            <div class="iq-card-geners card-hover-style-two">
                <div class="block-images position-relative w-100">
                    <div class="img-box rounded position-relative">
                        <img src="./assets/images/footer-logo/91.webp" alt="geners-img" class="img-fluid object-cover w-100 rounded">
                       
                    </div>
                </div>
            </div>
          </li>

          </ul>
          <div class="swiper-button swiper-button-next"></div>
          <div class="swiper-button swiper-button-prev"></div>
        </div>
      </div>
    </div>
  </div>
</div>
