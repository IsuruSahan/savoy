<?php
$hostname = "localhost"; // Your MySQL server address
$username = "monara_eft"; // Your MySQL username
$password = "monara_eft"; // Your MySQL password
$database = "monara_eft"; // Your MySQL database name
$prefix = "https://test.athavaneng.com/EFTF/Admin/uploads/";

$conn = new mysqli($hostname, $username, $password, $database);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>